package co.edu.uptc.runner;

import co.edu.uptc.presenter.Main;

public class Tester {
    public static void main(String[] args) {
        Main run = new Main();
        run.start();
    }
}
