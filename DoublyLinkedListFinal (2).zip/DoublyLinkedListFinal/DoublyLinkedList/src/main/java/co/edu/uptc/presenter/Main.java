package co.edu.uptc.presenter;

import co.edu.uptc.model.DoublyLinked;
import co.edu.uptc.pojo.Person;
import co.edu.uptc.util.ReadFile;
import co.edu.uptc.view.View;

import java.time.LocalDate;
import java.time.Period;

public class Main {

    private View view = new View();
    private DoublyLinked<Person> linked = new DoublyLinked<>();
    //para split:
    private DoublyLinked<Person> list1;
    private DoublyLinked<Person> list2;

    public void start(){
        ReadFile reader = new ReadFile();
        linked = reader.readWrite();
        menu();
    }

    public void menu() {
        int option;
        do {
        view.showMessage("Bienvenido al menú de su lista doblemente enlazada\n" +
                "OPCIONES--->\n" +
                "1. Salir\n" +
                "2. Mostrar lista\n" +
                "3. Añadir al inicio\n" +
                "4. Añadir al final\n" +
                "5. Añadir en el centro\n" +
                "6. Dividir lista\n" +
                "7. Ordenar\n" +
                "8. Adicionar ordenado\n" +
                "9. Dividir la lista según la edad de retiro\n" +
                "Seleccione una opción de las anteriores\n");
        option = view.readInt();

            switch (option) {
                case 1:
                    view.showMessage("Ha decicido salir del sistema");
                    break;
                case 2:
                    view.showMessage("Su lista actual se ve así:");
                    linked.showLinkedList();
                    break;
                case 3:
                    view.showMessage("Ha decicido añadir al inicio de la lista");
                    addFirst();
                    break;
                case 4:
                    view.showMessage("Ha decicido añadir al final de la lista");
                    addLast();
                    break;
                case 5:
                    view.showMessage("Ha decicido añadir en el centro de la lista");
                    addCentered();
                    break;
                case 6:
                    view.showMessage("Su lista será dividida en dos");

                    split();
                    break;
                case 7:
                    view.showMessage("Ha decicido ordenar");
                    sort();
                    break;
                case 8:
                    view.showMessage("Ha decicido adicionar de forma ordenada");
                    addtInOrder();
                    break;
                case 9:
                    view.showMessage("Ha decicido dividir la lista en dos sublistas según la edad de retiro");
                    asignationByRetirement();
                    break;
                default:
                    view.showMessage("Opción inválida");
            }
        } while (option != 1);

    }

    private void addFirst() {
        view.showMessage("Ingrese los datos solicitados:");
        Person person = view.createPerson();
        linked.addFirst(person);
        view.showMessage("Persona agregada al inicio");
    }

    private void addLast() {
        view.showMessage("Ingrese el dato: ");
        Person person = view.createPerson();

        linked.addLast(person);
        view.showMessage("Persona agregada al final");
    }

    private void addCentered() {
        view.showMessage("Ingrese el dato: ");
        Person person = view.createPerson();

        linked.addCentered(person);
        view.showMessage("Persona agregada en el centro de la lista");
    }

    public void split() {
        DoublyLinked<Person>[] list = linked.split();

        list1 = list[0];
        list2 = list[1];

        view.showMessage("Primera lista:");
        list1.showLinkedList();

        view.showMessage("Segunda lista:");
        list2.showLinkedList();
    }

    public void asignationByRetirement(){
        DoublyLinked<Person> listPass1 = new DoublyLinked<>();
        DoublyLinked<Person> listNotPass2 = new DoublyLinked<>();

        linked.asignationByRetirement();
    }

    public  void sort(){
        int[] attributes = selectedAttributes();
        int direction = view.selectDirection();

        linked.sort((p1,p2)-> {
            int result = comparatePerson(p1,p2,attributes);

            if (direction == 2) {
                result = result* -1;
            }
            return result;
        });

        System.out.println("\nLista ordenada:");
        linked.showLinkedList();
    }

    public void addtInOrder(){
        Person person = view.createPerson();
        int[] attributes = selectedAttributes();
        int direction = view.selectDirection();

        linked.addInOrder(person, (p1, p2) ->{
            int result = comparatePerson(p1, p2, attributes);
            if (direction == 2) {
                result = result* -1;
            }
            return result;
        });

        System.out.println("\nLa persona se añadido correctamente");
        linked.showLinkedList();
    }

    public int[] selectedAttributes(){
        int[] attributes = new int[5];
        int amount = 0;
        int option;

        do {
            option = view.selectAttributes();

            if (option >= 1 && option <= 5) {
                amount++;
                attributes[amount] = option;
            }

        }while(option != 6 && amount < 5);

        attributes[0] = amount;
        return attributes;
    }

    public int comparatePerson(Person p1, Person p2, int[] attributes){
        int amount = attributes[0];

        for (int i = 1; i < amount; i++) {
            int attribute = attributes[i];

            switch (attribute){
                case 1:
                    int comparateName =
                            p1.getName().compareToIgnoreCase(p2.getName());

                    if (comparateName != 0) {
                        return comparateName;
                    }
                    break;

                case 2:
                    int comparateLastName =
                            p1.getLastName().compareToIgnoreCase(p2.getLastName());

                    if (comparateLastName != 0) {
                        return comparateLastName;
                    }
                    break;

                case 3:
                    int edad1 = calculateAge(p1.getBirth());
                    int edad2 = calculateAge(p2.getBirth());

                    if (edad1 != edad2) {
                        return Integer.compare(edad1, edad2);
                    }
                    break;

                case 4:
                    int comparateGender =
                            p1.getGender().compareToIgnoreCase(p2.getGender());

                    if (comparateGender != 0) {
                        return comparateGender;
                    }
                    break;

                case 5:
                    int comparateState =
                            p1.getState().compareToIgnoreCase(p2.getState());

                    if (comparateState != 0) {
                        return comparateState;
                    }
                    break;

            }
        }
        return 0;
    }

    public int calculateAge(LocalDate birth){
        return Period.between(birth, LocalDate.now()).getYears();
    }
}